# ODYC Replit Starter (React + Supabase)

## Quick start (on Replit)
1. Create a new **Node.js** Repl and upload this folder (or unzip the zip).
2. Add Replit Secrets:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
3. In Supabase:
   - Run `supabase_schema.sql` in the SQL editor to create tables.
   - Enable Email + Google auth.
   - (Optional) Create a Storage bucket `artifacts` for uploads.
4. Install & run:
   ```bash
   npm install
   npm run dev
   ```

## What’s included
- Pathway Builder
- Project Card form
- Rubric Builder
- Student Transcript (simple PDF export)

## Next steps
- Role-based access (student/mentor/teacher/admin) via RLS.
- Scheduling + mentor approvals.
- Artifact uploads to Supabase Storage.
